let currentUser = null;

// Tambahkan warna background tiap halaman
const bgColors = {
  home: "#f4f4f4",
  about: "#fce4ec",
  courses: "#e3f2fd",
  register: "#fff3e0",
  login: "#ede7f6",
  contact: "#e8f5e9",
  dashboard: "#f0f4c3"
};

// Navigasi halaman
function navigate(page) {
  const content = document.getElementById("content");
  document.body.style.background = bgColors[page] || "#f4f4f4";

  let html = "";
  if (page === "home") {
    html = `
      <div class="card">
        <h2>Selamat Datang 👋</h2>
        <p>LPK Maju Bersama siap mencetak tenaga kerja <b>profesional</b> di bidang Garmen, IT, dan Bahasa.</p>
      </div>`;
  }
  else if (page === "about") {
    html = `
      <div class="card">
        <h2>Tentang Kami</h2>
        <p>LPK Maju Bersama berdiri sejak 2020. Fokus pada pelatihan kerja <b>praktis & siap pakai</b>.</p>
      </div>`;
  }
  else if (page === "courses") {
    html = `
      <div class="card">
        <h2>Program Pelatihan 📚</h2>
        <ul style="list-style:none;padding:0">
          <li>👕 Garmen (3 bulan)</li>
          <li>💻 IT & Coding (4 bulan)</li>
          <li>🌍 Bahasa Inggris (2 bulan)</li>
        </ul>
      </div>`;
  }
  else if (page === "register") {
    html = `
      <div class="card">
        <h2>📝 Pendaftaran Online</h2>
        <form onsubmit="submitForm(event)">
          <input type="text" id="regName" placeholder="Nama Lengkap" required><br>
          <input type="email" id="regEmail" placeholder="Email" required><br>
          <input type="password" id="regPassword" placeholder="Password" required><br>
          <select id="regProgram" required>
            <option value="">Pilih Program</option>
            <option>Garmen</option>
            <option>IT & Coding</option>
            <option>Bahasa Inggris</option>
          </select><br>
          <button type="submit">Daftar</button>
        </form>
      </div>`;
  }
  else if (page === "login") {
    if (currentUser) {
      showDashboard();
      return;
    }
    html = `
      <div class="card">
        <h2>🔑 Login Siswa</h2>
        <form onsubmit="login(event)">
          <input type="email" id="loginEmail" placeholder="Email" required><br>
          <input type="password" id="loginPassword" placeholder="Password" required><br>
          <button type="submit">Login</button>
        </form>
      </div>`;
  }
  else if (page === "contact") {
    html = `
      <div class="card">
        <h2>📞 Kontak Kami</h2>
        <p>📍 Jl. Pendidikan No. 10, Jakarta</p>
        <p>📱 <a href="https://wa.me/628990748906" target="_blank">Chat via WhatsApp</a></p>
        <p>✉️ info@lpkmajubersama.com</p>
      </div>`;
  }

  content.classList.remove("show");
  setTimeout(() => {
    content.innerHTML = html;
    content.classList.add("show");
    lucide.createIcons();
  }, 200);
}

// Registrasi
function submitForm(event) {
  event.preventDefault();
  const user = {
    name: document.getElementById("regName").value,
    email: document.getElementById("regEmail").value,
    password: document.getElementById("regPassword").value,
    program: document.getElementById("regProgram").value
  };
  localStorage.setItem("user_" + user.email, JSON.stringify(user));
  alert("✅ Pendaftaran berhasil! Silakan login.");
  navigate("login");
}

// Login
function login(event) {
  event.preventDefault();
  const email = document.getElementById("loginEmail").value;
  const password = document.getElementById("loginPassword").value;
  const storedUser = JSON.parse(localStorage.getItem("user_" + email));

  if (storedUser && storedUser.password === password) {
    currentUser = storedUser;
    showDashboard();
  } else {
    alert("❌ Email atau password salah!");
  }
}

// Dashboard
function showDashboard() {
  const content = document.getElementById("content");
  document.body.style.background = bgColors.dashboard;
  content.innerHTML = `
    <div class="dashboard">
      <h2>👩‍🎓 Dashboard Siswa</h2>
      <p>Selamat datang, <b>${currentUser.name}</b></p>
      <p>Program: ${currentUser.program}</p>
      <h3>📅 Jadwal Pelatihan</h3>
      <ul>
        <li>Senin & Rabu: 09.00 - 11.00</li>
        <li>Jumat: 13.00 - 15.00</li>
      </ul>
      <h3>📜 Sertifikat</h3>
      <p>(Belum tersedia)</p>
      <button onclick="logout()">Logout</button>
    </div>
  `;
}

// Logout
function logout() {
  currentUser = null;
  navigate("home");
}

// Default ke beranda
navigate("home");